export const CITIES: Record<string, [number, number]> = {
  LAGOS: [45, 160],
  IBADAN: [80, 132],
  ENUGU: [170, 152],
  ABUJA: [155, 102],
  ZARIA: [175, 64],
  KANO: [205, 36],
  MAIDUGURI: [325, 56]
};

export const COMPANIES = ['ROLLAND', 'KESTLE', 'TLRP', 'PSTL'];

export const CARGO: Record<string, { icon: string; trailer: string }> = {
  CARS: { icon: 'truck', trailer: 'carrier' },
  'PUFFED SNACKS': { icon: 'box', trailer: 'box' },
  MASCARA: { icon: 'box', trailer: 'box' },
  SERVERS: { icon: 'box', trailer: 'box' },
  EXPLOSIVES: { icon: 'box', trailer: 'hazmat' },
  SAND: { icon: 'truck', trailer: 'tipper' }
};
