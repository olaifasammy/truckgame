import { ic } from '../core/icons';
import { action, fmt, toast } from '../core/ui';
import { set } from '../core/store';
import { hire, fire, hireFee, fillPool } from '../systems/drivers';

action('hire', d => hire(+(d as any).id));
action('fire', d => fire(+(d as any).id));
action('logout', () => {
  set(S => {
    S.isAuthenticated = false;
  });
  toast('Logged out successfully');
  setTimeout(() => location.reload(), 500);
});

export default {
  id: 'company',
  icon: 'company',
  label: 'HQ Depot',
  render: (S: any) => {
    fillPool(S);
    return `
      <div class="profile-wrap">
        <div class="avatar">${S.company.charAt(0).toUpperCase()}</div>
        <div class="avatar-tx">${S.company}</div>
        <div class="mu-tx" style="font-size:11px;font-weight:700;letter-spacing:1px;margin-top:6px;">LOGISTICS HEADQUARTERS</div>
      </div>

      <div class="grid2">
        <div class="stat-box">
          <span class="stat-val">${S.loads}</span>
          <span class="stat-lab">Total Deliveries</span>
        </div>
        <div class="stat-box">
          <span class="stat-val">${S.drivers.length}</span>
          <span class="stat-lab">Active Personnel</span>
        </div>
        <div class="stat-box">
          <span class="stat-val" style="color:var(--grn);">$${S.stats.earned.toLocaleString()}</span>
          <span class="stat-lab">Gross Revenue</span>
        </div>
        <div class="stat-box">
          <span class="stat-val" style="color:var(--gold);">${S.stats.km.toLocaleString()} km</span>
          <span class="stat-lab">Distance Covered</span>
        </div>
      </div>

      <div class="sec"><span>Driver Personnel</span><span class="mu-tx">${S.drivers.length} EMPLOYED</span></div>
      ${S.drivers.map((d: any) => `
        <div class="card row">
          <div class="ico">${ic('user')}</div>
          <div class="info">
            <div class="c">${d.name}</div>
            <div class="d">Level ${d.skill} Driver</div>
          </div>
          <button class="btn alt red" style="padding:6px 12px;font-size:10px;" data-act="fire" data-id="${d.id}" ${S.drivers.length <= 1 ? 'disabled' : ''}>Terminate</button>
        </div>
      `).join('')}

      <div class="sec"><span>Recruitment Center</span><span class="mu-tx">HIRE DRIVERS</span></div>
      ${S.pool.map((d: any) => `
        <div class="card row">
          <div class="ico">${ic('user')}</div>
          <div class="info">
            <div class="c">${d.name}</div>
            <div class="d">Skill ${d.skill} · Fee ${fmt(hireFee(d))}</div>
          </div>
          <button class="btn gold" style="padding:6px 12px;font-size:10px;" data-act="hire" data-id="${d.id}" ${S.money < hireFee(d) ? 'disabled' : ''}>Hire</button>
        </div>
      `).join('')}

      <div class="sec"><span>Operations Log</span></div>
      ${S.notes.slice(0, 5).map((n: any) => `
        <div class="card" style="padding:12px;font-size:12px;">
          <div class="mu-tx" style="margin-bottom:4px;font-size:10px;font-weight:700;">TRANSMISSION RECEIVED</div>
          <div style="font-weight:600;">${n.t}</div>
        </div>
      `).join('')}

      <div style="padding:16px;">
        <button class="btn alt" style="width:100%;" data-act="logout">Sign Out of System</button>
      </div>
    `;
  }
};
