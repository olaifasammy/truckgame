import { placeBid } from '../../systems/jobs';
import { CARGO_TYPES } from '../../domain/freight/cargo/registry';
import { COMPANIES } from '../../domain/freight/companies/registry';
import { TRAILERS } from '../../domain/trucks/trucks.data';
import { dur } from '../../core/ui';
import { ic } from '../../core/icons';

export let activeAuctionModalId: number | null = null;

export function openAuctionModal(auctionId: number) {
  activeAuctionModalId = auctionId;
  const S = (window as any).__getStore?.();
  if (S) renderModalOverlay(S);
}

export function closeAuctionModal() {
  activeAuctionModalId = null;
  const existing = document.getElementById('auction-modal-overlay');
  if (existing) existing.remove();
}

export function renderModalOverlay(S: any) {
  if (activeAuctionModalId === null) return;
  const auc = (S.auctions || []).find((a: any) => a.id === activeAuctionModalId);
  if (!auc) {
    closeAuctionModal();
    return;
  }

  const cargo = CARGO_TYPES.find(c => c.id === auc.cargoId);
  const company = COMPANIES.find(c => c.id === auc.companyId);
  const timeLeft = Math.max(0, auc.expiresAt - Date.now());
  const isWinning = auc.currentWinner === 'player';
  
  // Dynamic undercuts: 1% and 3%
  const bid1 = Math.round(auc.currentBid * 0.99);
  const bid2 = Math.round(auc.currentBid * 0.97);

  let existing = document.getElementById('auction-modal-overlay');
  if (!existing) {
    existing = document.createElement('div');
    existing.id = 'auction-modal-overlay';
    document.body.appendChild(existing);
  }

  existing.style.cssText = `
    position: fixed; inset: 0; background: rgba(5,8,18,0.95);
    z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 16px;
  `;

  existing.innerHTML = `
    <div style="background:var(--s1); border:1px solid var(--gold); border-radius:12px; width:100%; max-width:440px; padding:20px; padding-right:48px; box-shadow:0 20px 40px rgba(0,0,0,0.6); position:relative; color:var(--tx);">
      <button id="close-auc-modal" style="position:absolute; top:14px; right:16px; background:none; border:none; color:var(--mu); font-size:18px; cursor:pointer; padding:4px 8px; z-index:10;">✕</button>
      
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">
        <span style="background:var(--gold); color:var(--bg); font-size:9px; font-weight:900; padding:2px 6px; border-radius:4px;">LIVE FREIGHT AUCTION</span>
        <span style="font-size:11px; color:var(--mu);">${company?.name || 'Enterprise Client'}</span>
      </div>

      <div style="display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:4px;">
        <h3 style="margin:0; font-size:16px; color:var(--tx);">${cargo?.name || 'Cargo'}</h3>
        <div style="color: var(--gold); font-size: 20px;">${ic(cargo?.icon || 'box')}</div>
      </div>
      <div style="font-size:12px; color:var(--accent); font-weight:700; margin-bottom:12px;">${auc.from} → ${auc.to} (${auc.km} km)</div>

      <div style="background:var(--bg); border:1px solid ${isWinning ? 'var(--accent)' : 'var(--line)'}; border-radius:8px; padding:14px; text-align:center; margin-bottom:16px; position:relative; overflow:hidden;">
        ${isWinning ? `<div style="position:absolute; top:0; left:0; right:0; height:2px; background:var(--accent);"></div>` : ''}
        <div style="font-size:10px; color:var(--mu); text-transform:uppercase; letter-spacing:1px;">Lowest Bid (Winning Price)</div>
        <div style="font-size:26px; font-weight:900; color:${isWinning ? 'var(--accent)' : 'var(--gold)'}; margin:4px 0;">$${(auc.currentBid || 0).toLocaleString()}</div>
        <div style="font-size:11px; color:var(--tx);">Leader: <b style="color:var(--accent);">${auc.currentWinnerName}</b></div>
        <div style="font-size:12px; font-weight:800; color:${timeLeft < 20000 ? '#ef4444' : 'var(--mu)'}; margin-top:6px;">
          ⏱️ Ends in: ${dur(timeLeft)}
        </div>
      </div>

      <div style="font-size:10px; color:var(--mu); text-align:center; margin-bottom:8px;">Lower your rate to beat competitors and secure the contract</div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:8px; margin-bottom:16px;">
        <button id="bid-1" class="btn" style="background:var(--gold); color:var(--bg); font-weight:800; padding:10px;" ${bid1 <= 0 || isWinning ? 'disabled' : ''}>
          Slight Undercut (-1%)<br><span style="font-size:10px; opacity:0.8;">$${(bid1 || 0).toLocaleString()}</span>
        </button>
        <button id="bid-2" class="btn" style="background:var(--gold); color:var(--bg); font-weight:800; padding:10px;" ${bid2 <= 0 || isWinning ? 'disabled' : ''}>
          Aggressive Bid (-3%)<br><span style="font-size:10px; opacity:0.8;">$${(bid2 || 0).toLocaleString()}</span>
        </button>
      </div>

      <div style="font-size:11px; font-weight:700; color:var(--mu); margin-bottom:6px;">Live Bidding History</div>
      <div style="max-height:120px; overflow-y:auto; background:var(--bg); border:1px solid var(--line); border-radius:6px; padding:8px; font-size:11px;">
        ${auc.bidHistory.length === 0 ? '<div style="color:var(--mu); text-align:center; padding:10px;">No bids placed yet. Be the first!</div>' : 
          auc.bidHistory.map((h: any, i: number) => `
            <div style="display:flex; justify-content:space-between; padding:4px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
              <span style="color:${i === 0 ? 'var(--accent)' : (h.bidderId === 'player' ? 'var(--gold)' : 'var(--tx)')}; font-weight:${i === 0 || h.bidderId === 'player' ? '800' : '400'};">
                ${i === 0 ? '👑 ' : ''}${h.bidderName}
              </span>
              <span style="font-weight:700; color:${i === 0 ? 'var(--accent)' : 'var(--mu)'};">$${(h.amount || 0).toLocaleString()}</span>
            </div>
          `).join('')}
      </div>
    </div>
  `;

  document.getElementById('close-auc-modal')?.addEventListener('click', closeAuctionModal);
  document.getElementById('bid-1')?.addEventListener('click', () => {
    if (bid1 > 0) placeBid(auc.id, bid1);
  });
  document.getElementById('bid-2')?.addEventListener('click', () => {
    if (bid2 > 0) placeBid(auc.id, bid2);
  });
}
