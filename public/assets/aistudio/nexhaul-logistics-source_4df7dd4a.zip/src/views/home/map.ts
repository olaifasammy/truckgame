import { CITIES } from '../../data/world';
import { homeState } from './state';

const line = (a: string, b: string, c: string, w: number, dash = '') => {
  const p1 = (CITIES as any)[a], p2 = (CITIES as any)[b];
  if (!p1 || !p2) return '';
  return `<line x1="${p1[0]}" y1="${p1[1]}" x2="${p2[0]}" y2="${p2[1]}" stroke="${c}" stroke-width="${w}" ${dash ? `stroke-dasharray="${dash}"` : ''}/>`;
};

export function renderMap(S: any) {
  const openId = homeState.openJobId;
  const oj = S.jobs.find((j: any) => j.id === openId), ends = oj ? [oj.from, oj.to] : [];
  
  const base = S.jobs
    .filter((j: any) => j.id !== openId)
    .map((j: any) => line(j.from, j.to, '#2d3e50', 1))
    .join('');
    
  const act = S.active.map((j: any) => line(j.from, j.to, '#10b981', 1.5, '3 3')).join('');
  const hl = oj ? line(oj.from, oj.to, '#c19a5b', 2, '5 4') : '';
  
  const nodes = Object.entries(CITIES).map(([c, p]: [string, any]) => {
    const on = ends.includes(c);
    return `
      <circle cx="${p[0]}" cy="${p[1]}" r="${on ? 5 : 3.5}" fill="${on ? '#c19a5b' : '#1e293b'}" stroke="#0a0f1d" stroke-width="1.5"/>
      <text x="${p[0]}" y="${p[1] + 15}" text-anchor="middle" font-size="9" fill="${on ? '#f1f5f9' : '#94a3b8'}" font-family="sans-serif" font-weight="700" letter-spacing=".5">${c}</text>
    `;
  }).join('');

  return `
    <div class="mapc">
      <div class="maph">
        <span>Logistics Network</span>
        <b>${oj ? oj.km + ' km' : S.jobs.length + ' routes'}</b>
      </div>
      <svg viewBox="0 0 370 190">${base}${act}${hl}${nodes}</svg>
    </div>
  `;
}
