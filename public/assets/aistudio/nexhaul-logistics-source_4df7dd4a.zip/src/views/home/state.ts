export const homeState = {
  openJobId: null as number | null
};
