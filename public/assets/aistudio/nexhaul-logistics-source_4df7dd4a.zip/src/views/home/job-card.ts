import { ic } from '../../core/icons';
import { fuelCost } from '../../systems/jobs';
import { TRAILERS } from '../../domain/trucks/trucks.data';
import { blocker } from '../../systems/jobs';
import { homeState } from './state';
import { CARGO_TYPES } from '../../domain/freight/cargo/registry';
import { COMPANIES } from '../../domain/freight/companies/registry';
import { dur } from '../../core/ui';

export function renderJobDetails(j: any, why: string | null) {
  const cargo = CARGO_TYPES.find(c => c.id === j.cargoId);
  const company = COMPANIES.find(c => c.id === j.companyId);
  const reqs = j.requirements?.requiredSkills || [];
  
  return `
    <div class="det">
      <div><small>Distance</small>${j.km || 0} km</div>
      <div><small>Weight</small>${j.weight || '---'} t</div>
      <div><small>Rate</small>${j.km ? (j.pay / j.km).toFixed(1) : '0'}/km</div>
      <div><small>Client</small>${company?.name || 'Private'}</div>
      <div><small>Trailer</small>${TRAILERS[cargo?.trailer || 'curtain']}</div>
      <div><small>Fuel use</small>${fuelCost(j)}%</div>
      ${reqs.length ? `<div style="grid-column: span 3; margin-top: 4px;"><small>Required Skills</small><div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:4px;">${reqs.map((s: string) => `<span style="font-size:8px;background:var(--s2);padding:2px 6px;border-radius:4px;color:var(--gold);border:1px solid var(--line);font-weight:800;letter-spacing:0.5px;">${s.toUpperCase()}</span>`).join('')}</div></div>` : ''}
      ${why ? `<div class="warn">${why}</div>` : ''}
    </div>
  `;
}

export function renderJobCard(S: any, j: any) {
  const cargo = CARGO_TYPES.find(c => c.id === j.cargoId);
  const why = blocker(S, j);
  const isOpen = homeState.openJobId === j.id;
  
  const cargoName = cargo?.name || j.cargo || 'General Freight';
  const isAuctionWon = (j as any).isAuctionWon;
  const wonAt = (j as any).wonAt;
  const FIVE_MINS = 5 * 60 * 1000;
  const expiryTime = wonAt ? wonAt + FIVE_MINS : 0;
  const timeLeft = expiryTime ? Math.max(0, expiryTime - Date.now()) : 0;
  
  return `
    <div class="card job ${j.vip || isAuctionWon ? 'vipj' : ''} ${isOpen ? 'open' : ''}" 
         style="${isAuctionWon ? 'border-color:var(--accent); background:rgba(16,185,129,0.05);' : ''}" 
         data-act="home-toggle" data-id="${j.id}">
      ${isAuctionWon ? `<div class="seal">SPECIAL</div>` : ''}
      <div class="jrow">
        <div class="ico" style="${isAuctionWon ? 'background:var(--accent);' : ''}">
          ${ic(isAuctionWon ? 'check' : (cargo?.icon || (cargo?.trailer === 'reefer' ? 'snowflake' : cargo?.trailer === 'tanker' ? 'fuel' : 'box')))}
        </div>
        <div class="info">
          <div class="c">
            ${cargoName}
            ${cargo?.isHazmat ? ' <span style="color:var(--gold);font-size:8px;vertical-align:middle;border:1px solid;padding:0 3px;border-radius:2px;margin-left:4px;">☢</span>' : ''}
          </div>
          <div class="d">${j.from} → ${j.to}</div>
          ${isAuctionWon && timeLeft > 0 ? `<div style="font-size:9px;color:var(--accent);font-weight:700;">Expiring in: <span data-eta="${expiryTime}">${dur(timeLeft)}</span></div>` : ''}
        </div>
        <div class="pay">
          <b style="${isAuctionWon ? 'color:var(--accent);' : ''}">$${(j.pay || 0).toLocaleString()}</b>
          <button class="btn ${why ? 'dim' : ''}" 
                  style="${isAuctionWon ? 'display:flex !important; background:var(--accent); opacity:1 !important; pointer-events:all !important;' : ''}" 
                  data-act="home-take" data-id="${j.id}">
            ${isAuctionWon ? 'Assign' : 'Accept'}
          </button>
        </div>
      </div>
      ${isOpen ? renderJobDetails(j, why) : ''}
    </div>
  `;
}
