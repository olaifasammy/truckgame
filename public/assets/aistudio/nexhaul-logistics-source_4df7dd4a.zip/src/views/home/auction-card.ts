import { ic } from '../../core/icons';
import { CARGO_TYPES } from '../../domain/freight/cargo/registry';
import { COMPANIES } from '../../domain/freight/companies/registry';
import { TRAILERS } from '../../domain/trucks/trucks.data';
import { dur } from '../../core/ui';

export function renderAuctionCard(S: any, j: any) {
  const auc = (S.auctions || []).find((a: any) => a.id === j.id);
  if (!auc || !auc.expiresAt) return '';

  const cargo = CARGO_TYPES.find(c => c.id === auc.cargoId);
  const company = COMPANIES.find(c => c.id === auc.companyId);
  const timeLeft = Math.max(0, auc.expiresAt - Date.now());

  return `
    <div class="card auction-card vipj" style="border-color:var(--gold); background:linear-gradient(135deg, rgba(193,154,91,0.08), var(--s1)); margin-bottom:6px; padding:8px 12px; border-radius:8px; border:1px solid var(--gold);">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
        <div style="display:flex; align-items:center; gap:8px;">
          <div style="width:30px; height:30px; background:var(--gold); color:var(--bg); border-radius:6px; display:flex; align-items:center; justify-content:center; font-size:14px;">${ic(cargo?.icon || 'box')}</div>
          <div>
            <div style="display:flex;align-items:center;gap:4px;">
              <span style="font-weight:700; font-size:12px; color:var(--tx);">${cargo?.name || 'Contract'}</span>
              <span style="font-size:7px;background:var(--gold);color:var(--bg);padding:1px 4px;border-radius:2px;font-weight:900;letter-spacing:0.3px;">LIVE</span>
            </div>
            <div style="font-size:10px; color:var(--accent); margin-top:1px;">${auc.from || j.from} → ${auc.to || j.to}</div>
            <div style="font-size:9px; color:var(--mu); margin-top:1px;">
              Leader: <span style="color:var(--tx); font-weight:600;">${auc.currentWinnerName || 'No bids yet'}</span>
            </div>
          </div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:11px; font-weight:900; color:var(--gold);">$${(auc.currentBid || 0).toLocaleString()}</div>
          <div style="font-size:10px; color:${timeLeft < 20000 ? '#ef4444' : 'var(--accent)'}; font-weight:800; margin:1px 0;">
            ⏳ <span data-eta="${auc.expiresAt}">${dur(timeLeft)}</span>
          </div>
          <button class="btn" style="background:var(--gold); color:var(--bg); font-weight:900; padding:2px 8px; font-size:9px; height:22px; border-radius:4px; display:inline-block; cursor:pointer;" data-act="open-auction" data-id="${auc.id}">Bid Room</button>
        </div>
      </div>
    </div>
  `;
}
