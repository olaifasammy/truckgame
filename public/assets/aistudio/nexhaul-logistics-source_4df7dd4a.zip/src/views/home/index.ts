import { refresh } from '../../core/store';
import { action } from '../../core/ui';
import { takeJob } from '../../systems/jobs';
import { renderMap } from './map';
import { renderJobCard } from './job-card';
import { renderAuctionCard } from './auction-card';
import { openAuctionModal, renderModalOverlay, activeAuctionModalId } from './auction-modal';
import { openTruckSelector, renderSelectorOverlay, activeSelectorJobId } from './truck-selector';
import { homeState } from './state';

action('home-toggle', d => {
  homeState.openJobId = homeState.openJobId === +(d as any).id ? null : +(d as any).id;
  refresh();
});

action('home-take', d => {
  const id = +(d as any).id;
  openTruckSelector(id);
});

action('open-auction', d => {
  openAuctionModal(+(d as any).id);
});

export default {
  id: 'home',
  icon: 'home',
  label: 'Home',
  render: (S: any) => {
    // Re-render modal overlays if active
    if (activeAuctionModalId !== null) {
      setTimeout(() => renderModalOverlay(S), 0);
    }
    if (activeSelectorJobId !== null) {
      setTimeout(() => renderSelectorOverlay(S), 0);
    }

    const auctions = S.auctions || [];
    const now = Date.now();
    
    return `
      ${renderMap(S)}
      ${auctions.length > 0 ? `
        <div class="sec">
          <span>Active Bidding / Auctions</span>
          <span class="mu-tx">${auctions.length} LIVE</span>
        </div>
        ${auctions.map((j: any) => renderAuctionCard(S, j)).join('')}
      ` : ''}
      <div class="sec">
        <span>Freight Board</span>
        <span class="mu-tx">${S.active.length} ACTIVE HAULS</span>
      </div>
      ${S.jobs.map((j: any) => renderJobCard(S, j)).join('')}
    `;
  }
};
