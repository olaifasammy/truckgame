import { ic } from '../core/icons';
import { action, fmt, dur } from '../core/ui';
import { refresh } from '../core/store';
import { TRUCK_MODELS, TRAILERS } from '../domain/trucks/trucks.data';
import { CITIES } from '../data/world';
import { stats, PART_LABELS, distKm } from '../systems/calc';
import { refuel, repair, inspect, assign, transport, refuelCost, repairCost, transportInfo, inspectCost } from '../systems/fleet';
import { why } from '../systems/jobs';
import { slots, upgradeGarage, upgradeGarageCost } from '../systems/offices';
import { openJobSelector, renderJobSelectorOverlay, activeJobSelectorTruckId } from './garage/job-selector';

let openId: number | null = null, panel: string | null = null;
action('truck-toggle', d => { openId = openId === +(d as any).id ? null : +(d as any).id; panel = null; refresh(); });
action('panel', d => { panel = panel === (d as any).kind ? null : (d as any).kind; refresh(); });
action('refuel', d => refuel(+(d as any).id));
action('repair', d => {
  const S = (window as any).__getStore?.();
  if (S) {
    S.repairTruckId = +(d as any).id;
    S.tab = 'repair';
    refresh();
  }
});
action('inspect', d => inspect(+(d as any).id));
action('dispatch', d => openJobSelector(+(d as any).id));
action('assign', d => assign(+(d as any).id, (d as any).driver ? +(d as any).driver : null));
action('move', d => transport(+(d as any).id, (d as any).city));
action('upgrade-garage', () => upgradeGarage());

const tone = (v: number) => v < 25 ? 'low' : v < 55 ? 'mid' : '';
const meter = (l: string, v: number, txt: string) => `<div class="meter"><div class="row" style="justify-content:space-between;font-size:10px;margin-bottom:4px;font-weight:700;"><span class="mu-tx">${l}</span><span>${txt}</span></div><div class="bar ${tone(v)}"><i style="width:${v}%"></i></div></div>`;
const cell = (k: string, v: string) => `<div class="stat-cell"><small class="mu-tx" style="display:block;font-size:9px;text-transform:uppercase;">${k}</small><span style="font-size:11px;font-weight:700;">${v}</span></div>`;

function panelHtml(S: any, t: any, busy: boolean) {
  if (panel === 'driver') return `<div class="panel" style="margin-top:16px;padding-top:16px;border-top:1px solid var(--line);">` + S.drivers.map((d: any) => {
    const cur = t.driverId === d.id, o = S.fleet.find((x: any) => x.driverId === d.id && x.id !== t.id), lock = o && o.status === 'busy';
    return `<div class="row" style="margin-bottom:12px;"><div class="info"><div class="c" style="font-size:13px;">${d.name}</div><div class="d">Skill ${d.skill}/5 · ${o ? 'On ' + o.name : cur ? 'This truck' : 'Available'}</div></div>
  <button class="btn alt" style="min-width:80px;padding:6px;" data-act="assign" data-id="${t.id}" data-driver="${d.id}" ${cur || busy || lock ? 'disabled' : ''}>${cur ? 'Assigned' : 'Assign'}</button></div>`;
  }).join('') +
    (t.driverId ? `<div class="row" style="margin-top:8px;justify-content:center;"><button class="btn alt" style="width:100%;" data-act="assign" data-id="${t.id}" data-driver="" ${busy ? 'disabled' : ''}>Unassign Current Driver</button></div>` : '') + `</div>`;
  if (panel === 'move') return `<div class="panel" style="margin-top:16px;padding-top:16px;border-top:1px solid var(--line);"><div class="mu-tx" style="font-size:11px;margin-bottom:12px;">Relocate truck to another office.</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">` +
    Object.keys(CITIES).filter(c => c !== t.loc).map(c => {
      const i = transportInfo(S, t, c);
      return `<button class="btn alt" style="flex-direction:column;align-items:flex-start;padding:10px;text-align:left;" data-act="move" data-id="${t.id}" data-city="${c}" ${i.why ? 'disabled' : ''}><b>${c}</b><span style="font-size:9px;color:var(--mu);margin-top:2px;">${i.km} km · ${dur(i.ms)}</span></button>`;
    }).join('') + `</div></div>`;
  return '';
}

function body(S: any, t: any, m: any, a: any, now: number) {
  const st = stats(S, t), busy = !!a, drv = S.drivers.find((x: any) => x.id === t.driverId);
  const pct = a ? Math.min(100, (now - a.start) / (a.end - a.start) * 100) : 0;
  
  const healthValues = Object.values(t.components).map((c: any) => c.health);
  const avgCond = Math.round(healthValues.reduce((a, b) => a + b, 0) / healthValues.length);
  const fuelPctVal = Math.round((t.fluids.fuel / m.tankSize) * 100);

  const hasCompatibleJobs = S.jobs.some((j: any) => !why(S, t, j));

  const componentMeters = Object.entries(t.components).map(([k, c]: [string, any]) => 
    meter(PART_LABELS[k] || k, c.health, Math.round(c.health) + '%')
  ).join('');

  return `<div class="tbody" style="margin-top:16px;padding-top:16px;border-top:1px solid var(--line);">
 ${a ? `<div class="row" style="margin-bottom:12px;justify-content:space-between;"><div class="info"><div class="c" style="font-size:13px;">${a.cargo}</div><div class="d">${a.from} → ${a.to}</div></div><div class="gold-tx" style="font-size:12px;font-weight:800;" data-eta="${a.end}">${dur(Math.max(0, a.end - now))}</div></div><div class="bar" style="margin-bottom:20px;" data-start="${a.start}" data-end="${a.end}"><i style="width:${pct}%;background:var(--blu);"></i></div>` : ''}
 <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">${meter('Fuel Tank', fuelPctVal, `${fuelPctVal}%`)}${meter('Overall Condition', avgCond, avgCond + '%')}</div>
 
 <div style="background:rgba(0,0,0,0.2);border-radius:10px;padding:12px;margin-bottom:16px;">
    <div class="row" style="justify-content:space-between;margin-bottom:10px;"><span class="gold-tx" style="font-size:10px;font-weight:700;">COMPONENT HEALTH</span></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">${componentMeters}</div>
 </div>

 <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:12px;margin-bottom:16px;">
   ${cell('Engine', m.engine.name)}
   ${cell('Power', m.engine.hp + ' hp')}
   ${cell('Torque', m.engine.torque + ' Nm')}
   ${cell('Transmission', m.trans)}
   ${cell('Axle', m.axle)}
   ${cell('Fuel Tank', m.tankSize + ' L')}
   ${cell('Top Speed', Math.round(st.topSpeed) + ' km/h')}
   ${cell('Consumption', Math.round(st.fuelConsumption) + ' L/100')}
   ${cell('Odometer', Math.round(t.odometer).toLocaleString() + ' km')}
 </div>
 
 <div class="mu-tx" style="font-size:10px;font-weight:700;background:var(--s2);padding:8px;border-radius:6px;margin-bottom:16px;text-align:center;">${m.haul.map((h: any) => TRAILERS[h as keyof typeof TRAILERS]).join(' · ')}</div>
 
 <button class="btn" style="width:100%;margin-bottom:16px;" data-act="dispatch" data-id="${t.id}" ${hasCompatibleJobs && !busy ? '' : 'disabled'}>${ic('send')} ${busy ? 'Currently Busy' : (hasCompatibleJobs ? 'Find Jobs on Board' : 'No Compatible Jobs Available')}</button>
 
 <div class="truck-actions" style="display:grid;grid-template-columns:repeat(3, 1fr);gap:8px;">
   <button class="btn alt" style="flex-direction:column;gap:4px;padding:8px;" data-act="refuel" data-id="${t.id}" ${busy || fuelPctVal >= 99 ? 'disabled' : ''}>${ic('fuel')} <span style="font-size:9px;">${fuelPctVal < 99 ? fmt(refuelCost(t)) : 'FULL'}</span></button>
   <button class="btn alt" style="flex-direction:column;gap:4px;padding:8px;" data-act="repair" data-id="${t.id}" ${busy ? 'disabled' : ''}>
     ${avgCond >= 100 ? ic('search') : ic('wrench')} 
     <span style="font-size:9px; color:${avgCond >= 100 ? 'var(--grn)' : 'var(--gold)'};">${avgCond >= 100 ? 'INSPECT' : 'REPAIR'}</span>
   </button>
   <button class="btn alt" style="flex-direction:column;gap:4px;padding:8px;" data-act="inspect" data-id="${t.id}" ${busy ? 'disabled' : ''}>${ic('search')} <span style="font-size:9px;">${fmt(inspectCost())}</span></button>
   <button class="btn alt ${panel === 'driver' ? 'gold' : ''}" style="flex-direction:column;gap:4px;padding:8px;" data-act="panel" data-kind="driver">${ic('user')} <span style="font-size:9px;">${drv ? drv.name.split(' ')[0].toUpperCase() : 'DRIVER'}</span></button>
   <button class="btn alt ${panel === 'move' ? 'gold' : ''}" style="flex-direction:column;gap:4px;padding:8px;" data-act="panel" data-kind="move">${ic('route')} <span style="font-size:9px;">TRAVEL</span></button>
 </div>${panelHtml(S, t, busy)}</div>`;
}

function truck(S: any, t: any) {
  const m = TRUCK_MODELS[t.modelId], a = S.active.find((x: any) => x.truck === t.id), now = Date.now(), o = openId === t.id;
  const drv = S.drivers.find((x: any) => x.id === t.driverId);
  const status = a ? { txt: a.kind === 'move' ? 'REPOSITIONING' : 'ON JOB', cls: 'grn-tx' } : drv ? { txt: 'READY', cls: 'gold-tx' } : { txt: 'NO DRIVER', cls: 'mu-tx' };
  
  const fuelPctVal = Math.round((t.fluids.fuel / m.tankSize) * 100);
  const healthValues = Object.values(t.components).map((c: any) => c.health);
  const avgCond = Math.round(healthValues.reduce((a, b) => a + b, 0) / healthValues.length);

  return `<div class="card ${o ? 'open' : ''}" style="cursor:pointer;" data-act="truck-toggle" data-id="${t.id}">
    <div class="row">
      <div class="truck-img">${ic('truck')}</div>
      <div class="info">
        <div class="c">${t.name}</div>
        <div class="d" style="font-weight:700;font-size:10px;letter-spacing:1px;margin-top:2px;">${m.brand} ${m.name} · ${t.loc}</div>
      </div>
      <div style="text-align:right;">
        <div class="${status.cls}" style="font-size:10px;font-weight:900;letter-spacing:1px;margin-bottom:6px;">${status.txt}</div>
        <div class="row" style="gap:4px;justify-content:flex-end;">
          <div class="bar" style="width:24px;margin:0;"><i style="width:${fuelPctVal}%;background:var(--gold);"></i></div>
          <div class="bar" style="width:24px;margin:0;"><i style="width:${avgCond}%;background:var(--grn);"></i></div>
        </div>
      </div>
    </div>
    ${o ? body(S, t, m, a, now) : ''}
  </div>`;
}

export default {
  id: 'garage',
  icon: 'garage',
  label: 'Garage',
  render(S: any) {
    const busy = S.fleet.filter((t: any) => t.status === 'busy').length;
    const upCost = upgradeGarageCost(S.garageLevel);
    const canUp = S.money >= upCost;

    return `<div class="grid2" style="background:var(--s1);border-bottom:1px solid var(--line);margin-bottom:12px;">
      <div class="stat-box" style="border:none;background:none;padding:12px;">
        <span class="stat-lab">Fleet Size</span>
        <div class="row" style="gap:8px;align-items:center;margin-top:2px;">
          <span class="stat-val" style="display:inline;">${S.fleet.length} / ${slots(S)}</span>
          <button class="btn alt" style="padding:2px 6px;font-size:8px;height:auto;border-radius:4px;" data-act="upgrade-garage" ${canUp ? '' : 'disabled'}>
            ${ic('up')} LVL ${S.garageLevel} UP (${fmt(upCost)})
          </button>
        </div>
      </div>
      <div class="stat-box" style="border:none;background:none;padding:12px;text-align:right;">
        <span class="stat-lab">Idle Trucks</span>
        <span class="stat-val" style="color:var(--gold);">${S.fleet.length - busy}</span>
      </div>
    </div>
    <div class="sec"><span>Logistics Fleet</span><span class="mu-tx">MANAGEMENT</span></div>
    ${S.fleet.map((t: any) => truck(S, t)).join('')}
    ${activeJobSelectorTruckId !== null ? renderJobSelectorOverlay(S) : ''}
    <div class="card row" style="padding:12px;margin-top:8px;border-color:var(--gold);background:rgba(193,154,91,0.1);" data-act="store-open" data-id="dealership">
      <div class="ico" style="background:var(--gold);color:var(--bg);">${ic('truck')}</div>
      <div class="info"><div class="c" style="color:var(--gold);">Truck Dealership</div><div class="d">Acquire new fleet assets</div></div>
      ${ic('chev')}
    </div>`;
  }
};
