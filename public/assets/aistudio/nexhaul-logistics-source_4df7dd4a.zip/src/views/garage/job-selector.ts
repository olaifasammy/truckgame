import { action, toast, fmt } from '../../core/ui';
import { refresh } from '../../core/store';
import { CARGO_TYPES } from '../../domain/freight/cargo/registry';
import { why, takeJob } from '../../systems/jobs';
import { ic } from '../../core/icons';

export let activeJobSelectorTruckId: number | null = null;

export function openJobSelector(truckId: number) {
  activeJobSelectorTruckId = truckId;
  const S = (window as any).__getStore?.();
  if (S) renderJobSelectorOverlay(S);
}

export function closeJobSelector() {
  activeJobSelectorTruckId = null;
  const existing = document.getElementById('job-selector-overlay');
  if (existing) existing.remove();
}

action('select-job-dispatch', d => {
  const jobId = +(d as any).jobId;
  const truckId = +(d as any).truckId;
  takeJob(jobId, truckId);
  closeJobSelector();
  refresh();
});

export function renderJobSelectorOverlay(S: any) {
  if (activeJobSelectorTruckId === null) return;
  const truck = S.fleet.find((t: any) => t.id === activeJobSelectorTruckId);
  if (!truck) {
    closeJobSelector();
    return;
  }

  // Filter jobs: Show only what this truck can do
  const jobs = S.jobs.filter((j: any) => !why(S, truck, j));

  let existing = document.getElementById('job-selector-overlay');
  if (!existing) {
    existing = document.createElement('div');
    existing.id = 'job-selector-overlay';
    document.body.appendChild(existing);
  }

  existing.style.cssText = `
    position: fixed; inset: 0; background: rgba(5,8,18,0.95);
    z-index: 1200; display: flex; align-items: center; justify-content: center; padding: 16px;
  `;

  existing.innerHTML = `
    <div style="background:var(--s1); border:1px solid var(--line); border-radius:16px; width:100%; max-width:480px; max-height:80vh; display:flex; flex-direction:column; box-shadow:0 25px 50px rgba(0,0,0,0.5); overflow:hidden; position:relative;">
      
      <!-- Header -->
      <div style="padding:20px; border-bottom:1px solid var(--line); background:var(--bg);">
        <button id="close-job-selector" style="position:absolute; top:16px; right:16px; background:none; border:none; color:var(--mu); font-size:20px; cursor:pointer;">✕</button>
        <h3 style="margin:0; font-size:18px; color:var(--tx);">Select Freight</h3>
        <div style="font-size:12px; color:var(--gold); font-weight:700; margin-top:4px;">
          ${truck.name} · ${truck.loc}
        </div>
      </div>

      <!-- List -->
      <div style="flex:1; overflow-y:auto; padding:12px; display:flex; flex-direction:column; gap:10px;">
        ${jobs.length === 0 ? '<div style="padding:40px; text-align:center; color:var(--mu);">No compatible jobs found on the Freight Board for this truck.</div>' : 
          jobs.map((j: any) => {
            const cargo = CARGO_TYPES.find(c => c.id === j.cargoId);
            const isSpecial = j.isAuctionWon;
            
            return `
              <div class="card" style="padding:12px; border-radius:10px; border:1px solid ${isSpecial ? 'var(--accent)' : 'var(--line)'}; background:var(--bg); display:flex; justify-content:space-between; align-items:center; position:relative; overflow:hidden;">
                ${isSpecial ? `<div class="seal" style="font-size:6px; padding:12px 20px 2px 20px;">SPECIAL</div>` : ''}
                <div style="display:flex; align-items:center; gap:12px;">
                  <div style="font-size:20px; color:var(--gold);">${ic(cargo?.icon || 'box')}</div>
                  <div>
                    <div style="font-weight:700; color:var(--tx); font-size:13px;">${cargo?.name || 'Cargo'}</div>
                    <div style="font-size:10px; color:var(--mu);">${j.from} → ${j.to} · ${j.km}km</div>
                  </div>
                </div>
                <div style="text-align:right;">
                  <div style="font-size:12px; font-weight:800; color:var(--grn); margin-bottom:4px;">$${j.pay.toLocaleString()}</div>
                  <button class="btn alt" data-act="select-job-dispatch" data-job-id="${j.id}" data-truck-id="${truck.id}" style="padding:4px 10px; font-size:10px; font-weight:800;">TAKE</button>
                </div>
              </div>
            `;
          }).join('')}
      </div>

      <div style="padding:12px; border-top:1px solid var(--line); text-align:center; font-size:10px; color:var(--mu); background:var(--bg);">
        Only jobs matching this truck's haul capabilities are shown.
      </div>
    </div>
  `;

  document.getElementById('close-job-selector')?.addEventListener('click', closeJobSelector);
}
