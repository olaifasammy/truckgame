import { TrailerType, TruckModel } from './trucks.types';

export const TRAILERS: Record<TrailerType, string> = {
  box: 'Box trailer',
  tipper: 'Tipper',
  carrier: 'Car carrier',
  hazmat: 'Hazmat tanker',
  curtain: 'Curtainside',
  reefer: 'Refrigerated',
  flatbed: 'Flatbed',
  tanker: 'Liquid tanker',
  lowboy: 'Lowboy trailer',
  rigid_box: 'Rigid Box (Short Haul)'
};

export const TRAILER_PRICES: Record<TrailerType, number> = {
  box: 14000,
  tipper: 18000,
  carrier: 20000,
  hazmat: 35000,
  curtain: 15000,
  reefer: 24000,
  flatbed: 12000,
  tanker: 22000,
  lowboy: 30000,
  rigid_box: 10000
};

export const TRUCK_MODELS: Record<string, TruckModel> = {
  // EUROPE
  'scania_s730': {
    id: 'scania_s730', brand: 'Scania', name: 'S730 V8 Highline', region: 'Europe', axle: '6x4',
    engine: { name: 'DC16 107', cylinders: 8, displacement: 16.4, hp: 730, torque: 3500, fuelType: 'Diesel' },
    trans: 'Opticruise 12+2', tankSize: 1200, oilCapacity: 45, baseWeight: 9.5, maxGVW: 60, price: 185000,
    haul: ['curtain', 'reefer', 'lowboy', 'tanker', 'hazmat', 'flatbed']
  },
  'merc_actros': {
    id: 'merc_actros', brand: 'Mercedes-Benz', name: 'Actros L 1863', region: 'Europe', axle: '4x2',
    engine: { name: 'OM 473', cylinders: 6, displacement: 15.6, hp: 625, torque: 3000, fuelType: 'Diesel' },
    trans: 'PowerShift 3', tankSize: 800, oilCapacity: 40, baseWeight: 8.2, maxGVW: 40, price: 145000,
    haul: ['curtain', 'reefer', 'box', 'tanker']
  },
  'volvo_fh16': {
    id: 'volvo_fh16', brand: 'Volvo', name: 'FH16 750', region: 'Europe', axle: '6x4',
    engine: { name: 'D16K750', cylinders: 6, displacement: 16.1, hp: 750, torque: 3550, fuelType: 'Diesel' },
    trans: 'I-Shift', tankSize: 1000, oilCapacity: 42, baseWeight: 9.8, maxGVW: 65, price: 195000,
    haul: ['curtain', 'reefer', 'lowboy', 'flatbed', 'hazmat']
  },
  'man_tgx': {
    id: 'man_tgx', brand: 'MAN', name: 'TGX 18.640', region: 'Europe', axle: '4x2',
    engine: { name: 'D3876', cylinders: 6, displacement: 15.2, hp: 640, torque: 3000, fuelType: 'Diesel' },
    trans: 'TipMatic 12', tankSize: 760, oilCapacity: 38, baseWeight: 8.5, maxGVW: 44, price: 138000,
    haul: ['curtain', 'box', 'reefer', 'tanker']
  },
  'daf_xf': {
    id: 'daf_xf', brand: 'DAF', name: 'XF 530 FT', region: 'Europe', axle: '4x2',
    engine: { name: 'PACCAR MX-13', cylinders: 6, displacement: 12.9, hp: 530, torque: 2600, fuelType: 'Diesel' },
    trans: 'TraXon 12', tankSize: 850, oilCapacity: 34, baseWeight: 8.0, maxGVW: 40, price: 125000,
    haul: ['curtain', 'box', 'reefer']
  },
  
  // AMERICA
  'kenworth_w900': {
    id: 'kenworth_w900', brand: 'Kenworth', name: 'W900 Studio Sleeper', region: 'America', axle: '6x4',
    engine: { name: 'Cummins X15', cylinders: 6, displacement: 15.0, hp: 605, torque: 2780, fuelType: 'Diesel' },
    trans: 'Eaton Fuller 18-spd', tankSize: 1500, oilCapacity: 48, baseWeight: 10.5, maxGVW: 55, price: 165000,
    haul: ['flatbed', 'lowboy', 'tipper', 'tanker']
  },
  'peterbilt_389': {
    id: 'peterbilt_389', brand: 'Peterbilt', name: '389 Pride & Class', region: 'America', axle: '6x4',
    engine: { name: 'PACCAR MX-13', cylinders: 6, displacement: 12.9, hp: 510, torque: 2500, fuelType: 'Diesel' },
    trans: 'Eaton UltraShift', tankSize: 1400, oilCapacity: 44, baseWeight: 10.2, maxGVW: 50, price: 158000,
    haul: ['flatbed', 'reefer', 'box', 'hazmat']
  },
  'freightliner_cascadia': {
    id: 'freightliner_cascadia', brand: 'Freightliner', name: 'Cascadia 126', region: 'America', axle: '6x4',
    engine: { name: 'Detroit DD15', cylinders: 6, displacement: 14.8, hp: 505, torque: 2370, fuelType: 'Diesel' },
    trans: 'DT12 AMT', tankSize: 1200, oilCapacity: 40, baseWeight: 9.0, maxGVW: 45, price: 135000,
    haul: ['box', 'reefer', 'curtain']
  },
  'mack_anthem': {
    id: 'mack_anthem', brand: 'Mack', name: 'Anthem 64T', region: 'America', axle: '6x4',
    engine: { name: 'Mack MP8', cylinders: 6, displacement: 13.0, hp: 505, torque: 2500, fuelType: 'Diesel' },
    trans: 'mDRIVE', tankSize: 1100, oilCapacity: 36, baseWeight: 8.8, maxGVW: 42, price: 128000,
    haul: ['box', 'tipper', 'flatbed']
  },

  // ASIA & SPECIAL
  'hino_700': {
    id: 'hino_700', brand: 'Hino', name: '700 Series Profia', region: 'Asia', axle: '6x4',
    engine: { name: 'E13C-VV', cylinders: 6, displacement: 12.9, hp: 480, torque: 2157, fuelType: 'Diesel' },
    trans: 'Pro Shift 16', tankSize: 600, oilCapacity: 32, baseWeight: 8.5, maxGVW: 40, price: 110000,
    haul: ['box', 'tipper', 'flatbed']
  },
  'isuzu_giga': {
    id: 'isuzu_giga', brand: 'Isuzu', name: 'Giga EXZ', region: 'Asia', axle: '6x4',
    engine: { name: '6WG1-TCS', cylinders: 6, displacement: 15.7, hp: 510, torque: 2255, fuelType: 'Diesel' },
    trans: 'MJX16 AMT', tankSize: 550, oilCapacity: 35, baseWeight: 9.0, maxGVW: 45, price: 115000,
    haul: ['box', 'tipper', 'tanker']
  },
  'howo_t7h': {
    id: 'howo_t7h', brand: 'SINOTRUK', name: 'HOWO T7H', region: 'Asia', axle: '6x4',
    engine: { name: 'MC11.44', cylinders: 6, displacement: 10.5, hp: 440, torque: 2100, fuelType: 'Diesel' },
    trans: 'HW19712', tankSize: 600, oilCapacity: 30, baseWeight: 9.2, maxGVW: 40, price: 85000,
    haul: ['tipper', 'flatbed', 'box']
  },
  'faw_j6p': {
    id: 'faw_j6p', brand: 'FAW', name: 'J6P 420', region: 'Asia', axle: '6x4',
    engine: { name: 'CA6DM2', cylinders: 6, displacement: 11.0, hp: 420, torque: 1900, fuelType: 'Diesel' },
    trans: 'CA12TAX', tankSize: 500, oilCapacity: 28, baseWeight: 8.8, maxGVW: 38, price: 78000,
    haul: ['tipper', 'flatbed', 'curtain']
  },

  // LIGHT & RIGID
  'merc_sprinter': {
    id: 'merc_sprinter', brand: 'Mercedes-Benz', name: 'Sprinter 519 CDI', region: 'Europe', axle: '4x2',
    engine: { name: 'OM 654', cylinders: 4, displacement: 2.0, hp: 190, torque: 450, fuelType: 'Diesel' },
    trans: '9G-TRONIC', tankSize: 93, oilCapacity: 11, baseWeight: 2.8, maxGVW: 5.5, price: 55000,
    haul: ['rigid_box']
  },
  'iveco_daily': {
    id: 'iveco_daily', brand: 'Iveco', name: 'Daily 70C21', region: 'Europe', axle: '4x2',
    engine: { name: 'FIC 3.0L', cylinders: 4, displacement: 3.0, hp: 210, torque: 470, fuelType: 'Diesel' },
    trans: 'Hi-Matic 8', tankSize: 100, oilCapacity: 12, baseWeight: 3.2, maxGVW: 7.2, price: 58000,
    haul: ['rigid_box', 'tipper']
  },
  'ford_f650': {
    id: 'ford_f650', brand: 'Ford', name: 'F-650 SD Gas', region: 'America', axle: '4x2',
    engine: { name: '7.3L V8 Godzilla', cylinders: 8, displacement: 7.3, hp: 350, torque: 635, fuelType: 'Diesel' },
    trans: '6-speed Auto', tankSize: 180, oilCapacity: 15, baseWeight: 5.5, maxGVW: 12.0, price: 72000,
    haul: ['rigid_box', 'tipper', 'flatbed']
  },
  'hino_300': {
    id: 'hino_300', brand: 'Hino', name: '300 Series 917', region: 'Asia', axle: '4x2',
    engine: { name: 'N04C', cylinders: 4, displacement: 4.0, hp: 165, torque: 464, fuelType: 'Diesel' },
    trans: '6-speed Manual', tankSize: 100, oilCapacity: 10, baseWeight: 3.0, maxGVW: 8.5, price: 48000,
    haul: ['rigid_box', 'tipper']
  },
  'fuso_canter': {
    id: 'fuso_canter', brand: 'Mitsubishi Fuso', name: 'Canter FE85', region: 'Asia', axle: '4x2',
    engine: { name: '4P10', cylinders: 4, displacement: 3.0, hp: 175, torque: 430, fuelType: 'Diesel' },
    trans: 'DUONIC 6-spd', tankSize: 100, oilCapacity: 10, baseWeight: 3.1, maxGVW: 8.5, price: 49500,
    haul: ['rigid_box', 'tipper']
  },

  // EXTRA HEAVY
  'scania_r500_8x4': {
    id: 'scania_r500_8x4', brand: 'Scania', name: 'R500 XT Heavy Tipper', region: 'Europe', axle: '8x4',
    engine: { name: 'DC13 155', cylinders: 6, displacement: 13.0, hp: 500, torque: 2550, fuelType: 'Diesel' },
    trans: 'Opticruise with Crawler', tankSize: 400, oilCapacity: 35, baseWeight: 15.0, maxGVW: 80, price: 168000,
    haul: ['tipper', 'lowboy']
  },
  'volvo_fmx_8x4': {
    id: 'volvo_fmx_8x4', brand: 'Volvo', name: 'FMX 540 Tipper', region: 'Europe', axle: '8x4',
    engine: { name: 'D13K540', cylinders: 6, displacement: 12.8, hp: 540, torque: 2600, fuelType: 'Diesel' },
    trans: 'I-Shift Crawler', tankSize: 450, oilCapacity: 38, baseWeight: 15.5, maxGVW: 85, price: 172000,
    haul: ['tipper', 'lowboy']
  }
};

export const MODELS = TRUCK_MODELS;
