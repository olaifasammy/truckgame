import { TRUCK_MODELS } from './trucks.data';
import { Truck, TruckModel } from './trucks.types';
import { Driver } from '../drivers/drivers.types';

export const PART_WEAR_COEFFICIENTS: Record<string, number> = {
  engine: 0.0001,
  transmission: 0.00008,
  brakes: 0.00015,
  tires: 0.0002,
  windshield: 0.00002,
  oilFilter: 0.0005,
  fuelFilter: 0.0004,
  airFilter: 0.0003,
  suspension: 0.00012
};

export interface PerformanceMetrics {
  topSpeed: number; // km/h
  acceleration: number; // 0-1 (normalized)
  fuelConsumption: number; // L/100km
  oilConsumption: number; // L/100km
  brakingDistance: number; // meters from 80km/h
}

/**
 * Calculates current truck performance based on its state and payload.
 */
export function calculatePerformance(truck: Truck, payloadTonnes: number, driver?: Driver): PerformanceMetrics {
  const model = TRUCK_MODELS[truck.modelId];
  const totalWeight = model.baseWeight + payloadTonnes;
  
  // 1. Calculate health modifiers
  const engineHealth = truck.components.engine.health / 100;
  const transHealth = truck.components.transmission.health / 100;
  const tireHealth = truck.components.tires.health / 100;
  
  // 2. Base Power/Weight ratio (hp per tonne)
  const powerWeightRatio = (model.engine.hp * engineHealth) / totalWeight;
  
  // 3. Top Speed calculation (capped by physics and gear)
  let topSpeed = powerWeightRatio * 15; // Rough heuristic
  topSpeed = Math.min(topSpeed, 140); // Hard cap
  if (driver) topSpeed *= (1 + (driver.skill / 50)); // Skilled drivers get slightly more out of the machine

  // 4. Acceleration factor
  const acceleration = (powerWeightRatio / 100) * transHealth;

  // 5. Fuel consumption based on load and HP
  // Formula: (Base + (Load * factor)) * (Engine Health factor)
  let fuelConsumption = (model.engine.hp / 20) + (payloadTonnes * 0.8);
  fuelConsumption *= (2 - engineHealth); // Worse engine = more fuel
  if (truck.upgrades.ecoTuning > 0) fuelConsumption *= (1 - (0.05 * truck.upgrades.ecoTuning));

  // 6. Oil consumption
  const oilConsumption = (model.engine.displacement / 2) * (2 - engineHealth);

  // 7. Braking distance
  const brakingDistance = 35 * (totalWeight / 10) * (2 - (truck.components.brakes.health / 100)) * (2 - tireHealth);

  return {
    topSpeed,
    acceleration,
    fuelConsumption,
    oilConsumption,
    brakingDistance
  };
}

/**
 * Applies wear to all components based on distance traveled.
 */
export function applyTripWear(truck: Truck, distanceKm: number, payloadTonnes: number) {
  const loadFactor = 1 + (payloadTonnes / 20); // Heavier load = more wear
  
  Object.keys(truck.components).forEach(key => {
    const component = (truck.components as any)[key];
    const coefficient = PART_WEAR_COEFFICIENTS[key] || 0.0001;
    
    // Calculate wear amount
    let wear = distanceKm * coefficient * loadFactor;
    
    // Apply health reduction
    component.health = Math.max(0, component.health - wear);
  });
}

/**
 * Calculates fuel and oil usage for a trip.
 */
export function calculateUsage(truck: Truck, distanceKm: number, metrics: PerformanceMetrics) {
  const fuelUsed = (distanceKm / 100) * metrics.fuelConsumption;
  const oilUsed = (distanceKm / 100) * metrics.oilConsumption;
  
  return { fuelUsed, oilUsed };
}

/**
 * Initializes a new truck based on a model.
 */
export function createTruck(id: number, modelId: string, name: string, loc: string, trailer: TrailerType | null = null): Truck {
  const model = TRUCK_MODELS[modelId];
  
  return {
    id,
    modelId,
    name,
    odometer: 0,
    loc,
    status: 'idle',
    driverId: null,
    trailer,
    fluids: {
      fuel: model.tankSize,
      oil: model.oilCapacity,
      coolant: 100,
      adBlue: 100
    },
    components: {
      engine: { health: 100, wearRate: 1 },
      transmission: { health: 100, wearRate: 1 },
      brakes: { health: 100, wearRate: 1 },
      tires: { health: 100, wearRate: 1 },
      windshield: { health: 100, wearRate: 1 },
      oilFilter: { health: 100, wearRate: 1 },
      fuelFilter: { health: 100, wearRate: 1 },
      airFilter: { health: 100, wearRate: 1 },
      suspension: { health: 100, wearRate: 1 }
    },
    upgrades: {
      ecoTuning: 0,
      performanceChip: 0,
      heavyDutySuspension: false
    }
  };
}
