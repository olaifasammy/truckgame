import { JobAuction, BidHistoryItem } from './types';
import { COMPETITORS, getRandomCompetitor } from './competitors';
import { CARGO_TYPES } from '../cargo/registry';
import { COMPANIES } from '../companies/registry';

export class BiddingEngine {
  /**
   * Converts a standard high-value job into an active auction
   */
  static createAuction(job: any, durationMs = 120000): JobAuction {
    const startingBid = Math.round(job.pay * 1.15); 
    
    return {
      id: job.id,
      companyId: job.companyId,
      cargoId: job.cargoId,
      from: job.from,
      to: job.to,
      km: job.km,
      weight: job.weight,
      startingBid,
      currentBid: startingBid,
      currentWinner: 'none',
      currentWinnerName: 'No bids yet',
      expiresAt: Date.now() + durationMs,
      durationMs,
      bidHistory: [],
      requirements: job.requirements,
      vip: job.vip
    };
  }

  /**
   * Process AI competitor bids during game loop tick
   */
  static tickAuctions(S: any, now: number) {
    if (!S.auctions) S.auctions = [];
    if (!S.jobs) S.jobs = [];
    
    let stateChanged = false;

    // 1. Check for Expired "Won" Jobs (5 minute window)
    const FIVE_MINS = 5 * 60 * 1000;
    const initialJobCount = S.jobs.length;
    S.jobs = S.jobs.filter((j: any) => {
      if (j.isAuctionWon && j.wonAt && (now - j.wonAt > FIVE_MINS)) {
        if (!S.notifications) S.notifications = [];
        S.notifications.unshift({
          id: Date.now(),
          text: `⚠️ Contract Expired: Dispatch for ${j.from} haul missed.`,
          time: Date.now(),
          read: false
        });
        return false;
      }
      return true;
    });
    if (S.jobs.length !== initialJobCount) stateChanged = true;

    const active: JobAuction[] = [];
    const expired: JobAuction[] = [];

    for (const auc of S.auctions) {
      if (now >= auc.expiresAt) {
        expired.push(auc);
        stateChanged = true;
      } else {
        const timeLeft = auc.expiresAt - now;
        
        let bidChance = 0.12; // Base chance
        if (timeLeft < 20000) bidChance = 0.5; // High intensity last 20s
        else if (timeLeft < 60000) bidChance = 0.25;

        if (Math.random() < bidChance) {
          if (this.simulateCompetitorBid(auc)) {
            stateChanged = true;
          }
        }
        active.push(auc);
      }
    }

    if (stateChanged) {
      S.auctions = active;
      // Handle expired auctions
      for (const auc of expired) {
        this.finalizeAuction(S, auc);
      }
    }
  }

  /**
   * Simulate a competitor placing a bid
   */
  static simulateCompetitorBid(auc: JobAuction): boolean {
    const competitor = getRandomCompetitor();
    const timeLeft = auc.expiresAt - Date.now();
    
    const profitFloor = auc.startingBid * (0.75 + (Math.random() * 0.12));
    if (auc.currentBid <= profitFloor) return false;

    const dropPct = 0.008 + (Math.random() * 0.02 * competitor.aggression);
    let newBid = Math.round(auc.currentBid * (1 - dropPct));

    if (timeLeft < 10000) {
      newBid = auc.currentBid - Math.floor(100 + Math.random() * 300);
    }

    newBid = Math.max(newBid, Math.round(profitFloor));

    if (newBid < auc.currentBid && auc.currentWinner !== competitor.id) {
      auc.currentBid = newBid;
      auc.currentWinner = competitor.id;
      auc.currentWinnerName = competitor.name;
      
      auc.bidHistory.unshift({
        bidderId: competitor.id,
        bidderName: competitor.name,
        amount: newBid,
        time: Date.now()
      });

      if (auc.bidHistory.length > 10) auc.bidHistory.pop();
      return true;
    }
    return false;
  }

  /**
   * Player places a bid
   */
  static placePlayerBid(S: any, auctionId: number, bidAmount: number): boolean {
    if (!S.auctions) return false;
    const auc = S.auctions.find((a: any) => a.id === auctionId);
    if (!auc || Date.now() >= auc.expiresAt) return false;

    if (bidAmount >= auc.currentBid) {
      // Must beat current bid
      return false;
    }

    auc.currentBid = bidAmount;
    auc.currentWinner = 'player';
    auc.currentWinnerName = 'Your Company (NexHaul)';

    auc.bidHistory.unshift({
      bidderId: 'player',
      bidderName: 'Your Company (NexHaul)',
      amount: bidAmount,
      time: Date.now()
    });

    return true;
  }

  /**
   * Finalize expired auction
   */
  static finalizeAuction(S: any, auc: JobAuction) {
    if (auc.currentWinner === 'player') {
      const cargo = CARGO_TYPES.find(c => c.id === auc.cargoId);
      const company = COMPANIES.find(c => c.id === auc.companyId);
      
      const wonJob = {
        id: auc.id,
        companyId: auc.companyId,
        cargoId: auc.cargoId,
        kind: 'Contract' as const,
        weight: auc.weight,
        from: auc.from,
        to: auc.to,
        km: auc.km,
        pay: auc.currentBid, 
        deadline: Date.now() + (auc.km * 3600000 / 60) + (24 * 3600000),
        requirements: auc.requirements,
        vip: auc.vip,
        isAuctionWon: true,
        wonAt: Date.now() // Track when it was won for the 5-min expiry
      };

      if (!S.jobs) S.jobs = [];
      S.jobs.unshift(wonJob);

      if (!S.notifications) S.notifications = [];
      S.notifications.unshift({
        id: Date.now(),
        text: `Contract Secured: ${cargo?.name} for $${auc.currentBid.toLocaleString()}`,
        time: Date.now(),
        read: false
      });
      
      // Also show a toast immediately
      // Note: we can't call toast() directly here if S is a draft, but we can rely on main.ts
    }
  }
}
