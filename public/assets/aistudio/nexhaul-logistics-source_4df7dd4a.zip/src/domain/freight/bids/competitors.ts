import { CompetitorBidder, Region } from './types';

const REGIONS: Region[] = ['NA', 'EU', 'AS', 'AF'];
const PREFIXES = [
  'Apex', 'Global', 'Trans', 'Metro', 'Interstate', 'Continental', 'Prime', 'Swift', 'Vanguard', 'Omega',
  'Titan', 'Summit', 'Pioneer', 'Polaris', 'Atlas', 'Nova', 'Zenith', 'Horizon', 'Alpha', 'Velocity',
  'Nexus', 'Quantum', 'Meridian', 'Vortex', 'Dynamic', 'Pacific', 'Atlantic', 'Saharan', 'Nile', 'Balkan'
];
const SUFFIXES = [
  'Logistics', 'Haulage', 'Freight', 'Transport', 'Cargo', 'Express', 'Shipping', 'Transit', 'Distribution', 'Drivers'
];

function generateCompetitors(): CompetitorBidder[] {
  const list: CompetitorBidder[] = [];
  let idCounter = 1;
  
  for (const region of REGIONS) {
    for (let i = 0; i < 30; i++) { // 30 per region = 120 competitors total
      const prefix = PREFIXES[(idCounter * 7) % PREFIXES.length];
      const suffix = SUFFIXES[(idCounter * 13) % SUFFIXES.length];
      const name = `${prefix} ${region} ${suffix} ${idCounter}`;
      
      list.push({
        id: `comp_${region.toLowerCase()}_${idCounter}`,
        name,
        region,
        aggression: parseFloat((0.7 + Math.random() * 0.7).toFixed(2)),
        budgetCapMultiplier: parseFloat((1.0 + Math.random() * 0.5).toFixed(2))
      });
      idCounter++;
    }
  }
  
  return list;
}

export const COMPETITORS = generateCompetitors();

export function getRandomCompetitor(region?: Region): CompetitorBidder {
  const filtered = region ? COMPETITORS.filter(c => c.region === region) : COMPETITORS;
  return filtered[Math.floor(Math.random() * filtered.length)];
}
