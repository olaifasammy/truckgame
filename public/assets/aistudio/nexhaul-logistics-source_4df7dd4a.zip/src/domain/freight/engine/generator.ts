import { Region, FreightJob, JobKind } from '../types';
import { COMPANIES } from '../companies/registry';
import { CARGO_TYPES } from '../cargo/registry';
import { CITIES } from '../../../data/world';
import { rnd } from '../../../core/ui';
import { BiddingEngine } from '../bids/engine';

export class FreightEngine {
  /**
   * Generates a realistic freight job or auction
   */
  static generate(S: any, options: { forceRegion?: Region, vip?: boolean, isAuction?: boolean, auctionDuration?: number } = {}): FreightJob | any {
    const cargo = rnd(CARGO_TYPES);
    const company = rnd(COMPANIES);

    const cityNames = Object.keys(CITIES);
    const from = rnd(cityNames);
    let to = rnd(cityNames);
    while (to === from) to = rnd(cityNames);

    const baseKm = 300 + Math.floor(Math.random() * 1500);

    let weight = 5 + Math.random() * 20;
    if (cargo.trailer === 'lowboy') weight = 20 + Math.random() * 40;

    let rate = cargo.baseValue;
    if (options.vip) rate *= 1.8;
    if (cargo.isHazmat) rate *= 1.4;
    if (cargo.tempControlled) rate *= 1.2;
    if (weight > 10) rate *= (1 + (weight - 10) * 0.02);

    // If it's an auction, base pay is 25% higher due to high demand
    if (options.isAuction) rate *= 1.25;

    const pay = Math.round(baseKm * rate);

    const dice = Math.random();
    let kind: JobKind = 'Spot';
    if (options.isAuction) kind = 'Contract';
    else if (dice > 0.8) kind = 'Contract';
    else if (dice > 0.95) kind = 'Emergency';

    const requiredSkills: string[] = [];
    if (cargo.isFragile) requiredSkills.push('Fragile Handling');
    if (cargo.tempControlled) requiredSkills.push('Cold Chain');
    if (cargo.isHazmat) requiredSkills.push('Hazardous Materials');
    if (baseKm > 1000) requiredSkills.push('Long Distance');

    const job = {
      id: S.nextId++,
      companyId: company.id,
      cargoId: cargo.id,
      kind,
      weight: parseFloat(weight.toFixed(1)),
      from,
      to,
      km: baseKm,
      pay,
      deadline: Date.now() + (baseKm * 3600000 / 60) + (12 * 3600000),
      requirements: {
        requiredSkills,
        minLevel: options.vip ? 5 : 1,
        adrClass: cargo.adrClass,
        reefer: cargo.tempControlled
      },
      vip: options.vip,
      isAuction: options.isAuction
    };

    if (options.isAuction) {
      const auction = BiddingEngine.createAuction(job, options.auctionDuration);
      if (!S.auctions) S.auctions = [];
      S.auctions.push(auction);
      return { ...job, isAuction: true, auctionId: auction.id };
    }

    return job;
  }

  static replenish(S: any, count = 8) {
    if (!S.jobs) S.jobs = [];
    if (!S.auctions) S.auctions = [];

    // Staggered Auctions: 1 to 3 active auctions with different durations
    const targetAuctions = 2 + Math.floor(Math.random() * 2); 
    while (S.auctions.length < targetAuctions) {
      // Random duration between 90s and 180s to stagger expiries
      const customDuration = (90 + Math.floor(Math.random() * 90)) * 1000;
      this.generate(S, { 
        isAuction: true, 
        vip: Math.random() < 0.3,
        auctionDuration: customDuration 
      });
    }

    while (S.jobs.length < count) {
      S.jobs.push(this.generate(S, { vip: Math.random() < 0.15 }));
    }
  }
}
