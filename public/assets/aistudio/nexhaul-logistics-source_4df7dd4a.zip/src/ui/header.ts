import { $, fmt, action } from '../core/ui';
import { ic } from '../core/icons';
import { set, refresh } from '../core/store';

let open = false;
action('bell', () => {
  open = !open;
  if (open) {
    set(S => { S.notes.forEach((n: any) => { n.r = 1; }); });
  } else {
    refresh();
  }
});

document.addEventListener('click', e => {
  if (open && !(e.target as HTMLElement).closest('#header')) {
    open = false;
    refresh();
  }
});

const chip = (icon: string, val: string, cls = '') => `
  <div class="chip ${cls}">
    ${ic(icon)}
    <span>${val}</span>
  </div>
`;

export function render(S: any) {
  const un = S.notes.filter((n: any) => !n.r).length;
  const ini = S.company.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase();
  const h = $('header');
  if (!h) return;

  h.innerHTML = `
    <div class="ring">
      <svg viewBox="0 0 48 48">
        <circle class="bg" cx="24" cy="24" r="21"/>
        <circle class="fg" cx="24" cy="24" r="21" stroke-linecap="round" 
          style="stroke-dashoffset:${132 * (1 - S.xp / 1000)}"/>
      </svg>
      <div class="av">${ini}</div>
      <span class="badge">VIP ${S.vip}</span>
    </div>

    <div class="who">
      <div class="rowt">
        <div class="co">${S.company}</div>
        <div style="display: flex; align-items: center; gap: 8px; position: relative;">
          <div class="cur">
            ${chip('coin', S.coins)}
            ${chip('cash', fmt(S.money), 'm')}
          </div>
          <div style="display: flex; flex-direction: column; align-items: center; gap: 4px;">
            <button class="bell" data-act="bell">
              ${ic('bell')}
              ${un ? `<em>${un}</em>` : ''}
            </button>
            <button class="rank-btn" data-act="tab" data-id="rankings">
              ${ic('up')}
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="np ${open ? 'on' : ''}">
      ${S.notes.map((n: any) => `<div>${n.t}</div>`).join('') || '<div>No notifications</div>'}
    </div>
  `;
}
