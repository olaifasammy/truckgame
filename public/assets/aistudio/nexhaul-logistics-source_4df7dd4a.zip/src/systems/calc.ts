import { TRUCK_MODELS } from '../domain/trucks/trucks.data';
import { calculatePerformance, calculateUsage, applyTripWear } from '../domain/trucks/trucks.physics';
import { CITIES } from '../data/world';

export const PART_LABELS: Record<string, string> = { 
  engine: 'Engine', 
  transmission: 'Transmission', 
  brakes: 'Brakes', 
  tires: 'Tires',
  windshield: 'Windshield',
  oilFilter: 'Oil Filter',
  fuelFilter: 'Fuel Filter',
  airFilter: 'Air Filter',
  suspension: 'Suspension'
};

export const distKm = (a: string, b: string): number => {
  const p = (CITIES as any)[a], q = (CITIES as any)[b];
  if (!p || !q) return 500;
  return Math.round(Math.hypot(p[0] - q[0], p[1] - q[1]) * 5.3 / 5) * 5;
};

export function stats(S: any, t: any, payloadTonnes = 0) {
  const d = S.drivers.find((x: any) => x.id === t.driverId);
  return calculatePerformance(t, payloadTonnes, d);
}

export const fuelCostForTrip = (km: number, t: any, payload = 0) => {
  const metrics = calculatePerformance(t, payload);
  return (km / 100) * metrics.fuelConsumption;
};

export const tripMs = (km: number, speed: number) => Math.round(km * 60 / speed);

export function applyWear(t: any, km: number, payload = 0) {
  applyTripWear(t, km, payload);
}

export function syncUsage(t: any, km: number, metrics: any) {
  const usage = calculateUsage(t, km, metrics);
  t.fluids.fuel = Math.max(0, t.fluids.fuel - usage.fuelUsed);
  t.fluids.oil = Math.max(0, t.fluids.oil - usage.oilUsed);
  t.odometer += km;
}
