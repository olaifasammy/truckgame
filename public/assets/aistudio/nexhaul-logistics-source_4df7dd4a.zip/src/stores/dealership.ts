import { ic } from '../core/icons';
import { action, fmt, toast } from '../core/ui';
import { refresh } from '../core/store';
import { TRUCK_MODELS, TRAILERS, TRAILER_PRICES } from '../domain/trucks/trucks.data';
import { TrailerType } from '../domain/trucks/trucks.types';
import { buyTruckBatch } from '../systems/fleet';
import { slots } from '../systems/offices';
import { CITIES } from '../data/world';

let selectedModelKey: string | null = null;
let configQuantity = 1;
let configTrailer: TrailerType | 'none' = 'none';
let configDestination = 'LAGOS';

action('inspect-truck', d => {
  selectedModelKey = (d as any).model;
  configQuantity = 1;
  const m = TRUCK_MODELS[selectedModelKey];
  configTrailer = m && m.haul.length > 0 ? m.haul[0] : 'none';
  configDestination = 'LAGOS';
  refresh();
});

action('close-truck-modal', () => {
  selectedModelKey = null;
  refresh();
});

action('config-qty-sub', () => {
  if (configQuantity > 1) configQuantity--;
  refresh();
});

action('config-qty-add', () => {
  configQuantity++;
  refresh();
});

action('config-trailer', d => {
  configTrailer = (d as any).trailer;
  refresh();
});

action('config-dest', d => {
  configDestination = (d as any).city;
  refresh();
});

action('execute-batch-buy', () => {
  if (!selectedModelKey) return;
  const tType = configTrailer === 'none' ? null : (configTrailer as TrailerType);
  buyTruckBatch(selectedModelKey, tType, configQuantity, configDestination);
  selectedModelKey = null;
  refresh();
});

const item = (S: any, k: string, m: any) => {
  return `
    <div class="card row" style="padding:12px; cursor:pointer;" data-act="inspect-truck" data-model="${k}">
      <div class="truck-img" style="width:50px; height:36px; font-size:18px;">${ic('truck')}</div>
      <div class="info">
        <div class="c" style="font-size:13px;">${m.brand} ${m.name}</div>
        <div class="d" style="font-size:10px;">
          ${m.engine.hp} hp · ${m.axle} · ${m.engine.cylinders === 8 ? 'V8' : 'I6'}<br>
          <span style="color:var(--accent); font-weight:700;">Tap to Configure & Acquire</span>
        </div>
      </div>
      <div style="text-align:right;">
        <div style="font-size:12px; font-weight:800; color:var(--grn); margin-bottom:4px;">${fmt(m.price)}</div>
        <span style="font-size:10px; font-weight:700; color:var(--gold);">CONFIG →</span>
      </div>
    </div>
  `;
};

export default {
  id: 'dealership',
  icon: 'truck',
  label: 'Truck Dealership',
  desc: 'Acquire new fleet assets',
  render: (S: any) => {
    const regions = ['Europe', 'America', 'Asia'];
    const models = Object.entries(TRUCK_MODELS);
    const inspectedModel = selectedModelKey ? TRUCK_MODELS[selectedModelKey] : null;

    // Calculate totals
    const trailerPrice = configTrailer !== 'none' ? (TRAILER_PRICES[configTrailer as TrailerType] || 15000) : 0;
    const unitPrice = inspectedModel ? inspectedModel.price + trailerPrice : 0;
    const totalPrice = unitPrice * configQuantity;
    const canAfford = S.money >= totalPrice;
    const hasSpace = S.fleet.length + configQuantity <= slots(S);

    return `
      <div class="sec">
        <span>Available Inventory</span>
        <span class="mu-tx">${S.fleet.length} / ${slots(S)} SLOTS</span>
      </div>
      ${regions.map(r => `
        <div style="padding:0 16px; margin:10px 0 6px; font-size:9px; font-weight:900; color:var(--mu); letter-spacing:1px; text-transform:uppercase;">${r} Manufacturers</div>
        ${models.filter(([_, m]) => m.region === r).map(([k, m]) => item(S, k, m)).join('')}
      `).join('')}

      <!-- Showroom Configuration & Purchase Modal -->
      ${inspectedModel && selectedModelKey ? `
        <div style="position:fixed; inset:0; background:rgba(5,8,18,0.95); z-index:1500; display:flex; align-items:center; justify-content:center; padding:16px;">
          <div style="background:var(--s1); border:1px solid var(--gold); border-radius:16px; width:100%; max-width:440px; max-height:90vh; overflow-y:auto; padding:20px; position:relative; box-shadow:0 25px 50px rgba(0,0,0,0.6);">
            <button style="position:absolute; top:14px; right:16px; background:none; border:none; color:var(--mu); font-size:18px; cursor:pointer; padding:4px 8px; z-index:10;" data-act="close-truck-modal">✕</button>
            
            <div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">
              <span style="background:var(--gold); color:var(--bg); font-size:9px; font-weight:900; padding:2px 6px; border-radius:4px;">FLEET CONFIGURATOR</span>
              <span style="font-size:11px; color:var(--mu);">${inspectedModel.region} Region</span>
            </div>

            <h3 style="margin:0 0 4px 0; font-size:18px; color:var(--tx);">${inspectedModel.brand} ${inspectedModel.name}</h3>
            <div style="font-size:12px; color:var(--gold); font-weight:700; margin-bottom:16px;">Base Price: ${fmt(inspectedModel.price)}</div>

            <!-- 1. Trailer Configuration -->
            <div style="margin-bottom:14px;">
              <div style="font-size:10px; font-weight:700; color:var(--mu); text-transform:uppercase; margin-bottom:6px;">1. Attach Trailer Attachment</div>
              <div style="display:flex; flex-wrap:wrap; gap:6px;">
                <button class="btn ${configTrailer === 'none' ? 'gold' : 'alt'}" style="padding:6px 10px; font-size:10px; font-weight:800;" data-act="config-trailer" data-trailer="none">
                  Tractor Only ($0)
                </button>
                ${inspectedModel.haul.map((h: string) => `
                  <button class="btn ${configTrailer === h ? 'gold' : 'alt'}" style="padding:6px 10px; font-size:10px; font-weight:800;" data-act="config-trailer" data-trailer="${h}">
                    ${TRAILERS[h as keyof typeof TRAILERS] || h} (+${fmt(TRAILER_PRICES[h as TrailerType] || 15000)})
                  </button>
                `).join('')}
              </div>
            </div>

            <!-- 2. Destination City -->
            <div style="margin-bottom:14px;">
              <div style="font-size:10px; font-weight:700; color:var(--mu); text-transform:uppercase; margin-bottom:6px;">2. Delivery Destination Office</div>
              <div style="display:flex; gap:6px; overflow-x:auto; padding-bottom:4px;">
                ${Object.keys(CITIES).map(city => `
                  <button class="btn ${configDestination === city ? 'gold' : 'alt'}" style="padding:6px 12px; font-size:10px; font-weight:800; white-space:nowrap;" data-act="config-dest" data-city="${city}">
                    ${city}
                  </button>
                `).join('')}
              </div>
            </div>

            <!-- 3. Quantity Stepper -->
            <div style="margin-bottom:16px; background:var(--bg); border:1px solid var(--line); border-radius:10px; padding:12px; display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="font-size:11px; font-weight:800; color:var(--tx);">Order Quantity</div>
                <div style="font-size:9px; color:var(--mu);">Available Slots: ${slots(S) - S.fleet.length}</div>
              </div>
              <div style="display:flex; align-items:center; gap:10px;">
                <button class="btn alt" style="width:30px; height:30px; padding:0; font-weight:900;" data-act="config-qty-sub">-</button>
                <span style="font-size:16px; font-weight:900; color:var(--gold); min-width:24px; text-align:center;">${configQuantity}</span>
                <button class="btn alt" style="width:30px; height:30px; padding:0; font-weight:900;" data-act="config-qty-add">+</button>
              </div>
            </div>

            <!-- Specs Summary -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:16px;">
              <div class="card" style="padding:8px; background:var(--bg);"><small style="font-size:9px; color:var(--mu);">HORSEPOWER</small><div style="font-size:12px; font-weight:800; color:var(--tx);">${inspectedModel.engine.hp} HP</div></div>
              <div class="card" style="padding:8px; background:var(--bg);"><small style="font-size:9px; color:var(--mu);">TORQUE</small><div style="font-size:12px; font-weight:800; color:var(--tx);">${inspectedModel.engine.torque} Nm</div></div>
            </div>

            <!-- Action Footer -->
            <div style="background:var(--bg); border:1px solid var(--line); border-radius:10px; padding:14px; display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="font-size:10px; color:var(--mu); text-transform:uppercase;">Total Price (${configQuantity}x)</div>
                <div style="font-size:18px; font-weight:900; color:var(--grn);">${fmt(totalPrice)}</div>
              </div>
              <button class="btn gold" style="padding:10px 16px; font-size:11px; font-weight:900;" data-act="execute-batch-buy" ${!canAfford || !hasSpace ? 'disabled' : ''}>
                ${!hasSpace ? 'GARAGE FULL' : 'ACQUIRE FLEET'}
              </button>
            </div>
          </div>
        </div>
      ` : ''}

      <div style="height:20px;"></div>
    `;
  }
};
